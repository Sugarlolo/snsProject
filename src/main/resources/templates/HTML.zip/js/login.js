$('.footer_load').load('footer.html');

document.addEventListener("DOMContentLoaded", function () {
    const images = document.querySelectorAll(".fade_img");
    let currentIndex = 0;
    images[0].style.opacity = 1;
    images[0].style.transition = "opacity 2s ease-in-out";

    function nextImage() {

        for (let i = 0; i < images.length; i++) {
            images[i].style.opacity = 0;
        }
        currentIndex = (currentIndex + 1) % images.length;

        images[currentIndex].style.transition = "opacity 2s ease-in-out";
        images[currentIndex].style.opacity = 1;
    }

    setInterval(nextImage, 5000);
});

$('.input_cont').on("click", "a", function () {
    var link = $(this).attr("id")

    var html_fir = "";
    var html_sec = "";
    if (link === "signup" || link === "signup_sec") {
        html_fir = '<img src="img/logo.png" alt="logo">' +
            '<span class="sign_text">친구들의 사진과 동영상을 보려면 가입하세요.</span>' +
            '<div class="fcbkImg">' +
            '<a href="#">' +
            '<img src="img/icons8-facebook-48.png" width="24px" height="24px" alt="fcbkLogo">' +
            '<h4>이거 카카오로 바뀔거임</h4>' +
            '</a>' +
            '</div>' +
            '<div class="hrTag">' +
            '<hr>' +
            '<p>OR</p>' +
            '<hr>' +
            '</div>' +
            '<form action="#" id="register_form">' +
            '<input type="text" id="register_auth" placeholder="휴대폰 번호 또는 이메일">' +
            '<input type="text" id="register_name" placeholder="사용자 이름">' +
            '<input type="text" id="register_id" placeholder="아이디">' +
            '<input type="password" id="register_pwd" placeholder="비밀번호">' +
            '<button id="register_btn">가입</button>' +
            '</form>';
        html_sec = '<div><p>이미 계정이 있나요? ' +
            '<a href="#" id="signin"> 로그인</a>' +
            '</p></div>';
        $('.input_form').html(html_fir);
        $('.sign_cont').html(html_sec);

    } else if (link === "signin") {
        html_fir = '<img src="img/logo.png" alt="logo">' +
            '<form action="#" id="login_form">' +
            '<input type="text" id="login_id" placeholder="전화번호, 아이디 또는 이메일">' +
            '<input type="password" id="login_pwd" placeholder="비밀번호">' +
            '<br>' +
            '<button id="logIn_btn">로그인</button>' +
            '<div class="hrTag">' +
            '<hr>' +
            '<p>OR</p>' +
            '<hr>' +
            '</div>' +
            '<div id="logFcbk">' +
            '<div class="logoFcbk">' +
            '<div class="fcbkImg">' +
            '<a href="#"><img src="img/icons8-facebook-48.png" width="24px" height="24px" alt="fcbkLogo">' +
            '<h4>이거 카카오로 바뀔거임</h4>' +
            '</a>' +
            '</div>' +
            '<div class="forgotPasswd">' +
            '<a href="#" id="find_pwd">또 까먹으셨나요 ?</a>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</form>';
        html_sec = '<div><p>아직도 아이디가 없나요? ' +
            '<a href="#" id="signup"> 바로 만들어</a>' +
            '</p></div>';
        
        $('.input_form').html(html_fir);
        $('.sign_cont').html(html_sec);
    } else if (link === "find_pwd") {
        html_fir =  '<div class="pwd_img">' +
                    '<span class="find_pwd_img"></span>' +
                    '</div>' +
                    '<div class="pwd_info_fir">' +
                    '<span>로그인에 문제가 있나요 ?</span>' +
                    '</div>' +
                    '<div class="pwd_info_sec">' +
                    '<span>이메일 주소를 입력하시면 계정에 다시' +
                    '엑세스 할 수 있는 링크를 보내드립니다.</span>' +
                    '</div>' +
                    '<form action="#" id="findpwd_form">' +
                    '<input type="text" id="find_pwd" placeholder="이메일">' +
                    '<button id="find_pwd_btn">로그인 링크 보내기</button>' +
                    '</form>' +
                    '<div class="hrTag">' +
                    '<hr>' +
                    '<p>OR</p>' +
                    '<hr>' +
                    '</div>' +
                    '<div class="signup_box">' +
                    '<a href="#" id="signup_sec"><span>새 계정 만들기</span></a>' +
                    '</div>' +
                    '</div>';
        html_sec =  '<div>' +
                    '<p>' +
                    '<a href="#" id="signin">로그인으로 돌아가기</a>' +
                    '</p>' +
                    '</div>';
        $('.input_form').html(html_fir);
        $('.sign_cont').html(html_sec);
    }
});
