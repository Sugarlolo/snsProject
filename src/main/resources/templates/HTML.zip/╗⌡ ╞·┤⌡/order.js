let slides = document.querySelector('.slide_track');
let slideImg = document.querySelectorAll('.slide_track li');
currentIdx = 1;
slideCount = slideImg.length;
prev = document.querySelector('.slide_prev');
next = document.querySelector('.slide_next');
slideWidth = 80;
slideMargin = 20;
let isAnimating = false;

Clone();
init();

function Clone() {
    var cloneArr = new Array(5);
    var cloneLast = slides.lastElementChild.cloneNode(true);

    for (let i = 0; i < 5; i++) {
        cloneArr[i] = slideImg[i].cloneNode(true);
        slides.append(cloneArr[i]);
    }
    slides.insertBefore(cloneLast, slides.firstElementChild);
}

function init() {
    slides.style.width = (slideWidth + slideMargin) * (slideCount + 6) + 'px';
    slides.style.left = -(slideWidth + slideMargin) + 'px';
}

next.addEventListener('click', async function() {
    if (!isAnimating) {
        isAnimating = true;

        // 클릭 동작을 비동기로 처리
        await new Promise(resolve => {
            currentIdx += 1;
            if (currentIdx <= slideCount + 1) {
                slides.style.left = -currentIdx * (slideWidth + slideMargin) + 'px';
                slides.style.transition = '0.5s ease-out';

                setTimeout(() => {
                    slides.style.transition = '0s ease-out';
                    if (currentIdx === slideCount + 1) {
                        slides.style.left = -(slideWidth + slideMargin) + 'px';
                        currentIdx = 1;
                    }
                    isAnimating = false;
                    resolve();
                }, 500);
            }
        });
    }
});


prev.addEventListener('click', async function() {
    if (!isAnimating) {
        isAnimating = true;

        await new Promise(resolve => {
            currentIdx -= 1;
            if (currentIdx >= 0) {
                slides.style.left = -currentIdx * (slideWidth + slideMargin) + 'px';
                slides.style.transition = '0.5s ease-out';

                setTimeout(() => {
                    slides.style.transition = '0s ease-out';
                    if (currentIdx === 0) {
                        slides.style.left = -slideCount * (slideWidth + slideMargin) + 'px';
                        currentIdx = slideCount;
                    }
                    isAnimating = false;
                    resolve();
                }, 500);
            }
        });
    }
});

function changeImg() {
    var imgElement = this.querySelector('img');
    var bigImgElement = document.querySelector('.b_photo');
    
    bigImgElement.src = imgElement.src;
}

window.addEventListener("scroll", function() {
    let scrollPosition = window.scrollY;
    
    const nav = document.getElementsByClassName('product_nav_bar')[0];
    const det = document.getElementById('detail');
    
    const absoluteTop = window.pageYOffset + nav.getBoundingClientRect().top;
    const compareTop = window.pageYOffset + det.getBoundingClientRect().top;
    
    console.log(compareTop);
    console.log(scrollPosition);
    if (scrollPosition + 60 <= compareTop) {
        nav.style.position = "static";
        nav.style.margin = "20px auto";
        det.style.marginTop = "0";
    } else if(scrollPosition > absoluteTop) {
        nav.style.position = "fixed";
        nav.style.top = "0";
        nav.style.width = "100%";
        nav.style.margin = "0 auto";
        det.style.marginTop = "100px";
    }
});